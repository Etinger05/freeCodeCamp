const analytics = {
  event: () => {}
};

export default analytics;
