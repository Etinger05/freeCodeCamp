---
title: Scientific Computing with Python
superBlock: scientific-computing-with-python
---
## Introduction to Scientific Computing with Python

Learn the basics of Python.
