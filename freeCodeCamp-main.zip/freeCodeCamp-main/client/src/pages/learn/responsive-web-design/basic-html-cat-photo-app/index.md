---
title: Introduction to the Basic HTML Cat Photo App
block: Basic HTML Cat Photo App
superBlock: Responsive Web Design
isBeta: true
---
## Introduction to the Basic HTML Cat Photo App

This is a test for the new project-based curriculum.