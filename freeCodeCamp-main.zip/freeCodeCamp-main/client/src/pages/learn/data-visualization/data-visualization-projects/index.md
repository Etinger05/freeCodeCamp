---
title: Introduction to the Data Visualization Projects
block: Data Visualization Projects
superBlock: Data Visualization
---
## Introduction to the Data Visualization Projects

These challenges let you test your data visualization skills and how to transfer and use data using AJAX technologies.

By the end of this, you would have 5 projects to showcase your data visualization skills that you can show off to friends, family, employers, etc. Have fun and remember to use the [Read-Search-Ask](https://forum.freecodecamp.org/t/how-to-get-help-when-you-are-stuck-coding/19514) method if you get stuck.
