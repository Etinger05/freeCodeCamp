---
title: JavaScript Algorithms and Data Structures
superBlock: javascript-algorithms-and-data-structures
---
## Introduction to JavaScript Algorithms and Data Structures

JavaScript Algorithms and Data Structures will teach you basic JavaScript in a series of challenges. It will teach you how to assign variables, arrays, create functions, and some of the various loop types used in JavaScript. Then it will teach you to apply what you’ve learned in multiple algorithm creation challenges. Once you have completed all the challenges and the required projects you will receive the JavaScript Algorithms and Data Structures certificate.
